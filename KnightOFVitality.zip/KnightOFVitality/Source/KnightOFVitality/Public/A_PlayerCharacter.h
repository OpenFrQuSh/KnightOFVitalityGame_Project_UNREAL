// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "PaperSprite.h"
#include "PaperFlipbook.h"
#include "PaperSpriteComponent.h"
#include "PaperFlipbookComponent.h"
#include "Camera/CameraComponent.h"
#include "Components/BoxComponent.h"
#include "DrawDebugHelpers.h"
#include "Components/CapsuleComponent.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "GameFramework/SpringArmComponent.h"
#include "A_PlayerCharacter.generated.h"

/**
 * 
 */
UCLASS()
class KNIGHTOFVITALITY_API AA_PlayerCharacter : public APawn
{
	GENERATED_BODY()
public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "MoveSpeed")
	float MoveSpeed;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "bIsThrowingBoomerang")
	bool bIsThrowingBoomerang;
	bool bIsAttacking;
	bool bIsRolling;
	float CurrentInputX = 0;
	float CurrentInputY = 0;
	FTimerHandle DodgeTimerHandle;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "BoomerangSpeed")
	float BoomerangSpeed;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "MaxBoomerangDistance")
	float MaxBoomerangDistance;
	float BoomerangElapsed;
	FVector2D BoomerangDirection;
	FVector2D BoomerangStartLocation;
	UPROPERTY(VisibleAnywhere)
	APlayerController* PC;
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category="Boxdamage")
	UBoxComponent* Boxdamage;
	UPROPERTY(EditAnywhere)
	UPaperFlipbook* IdleFlipbook;
	UPROPERTY(EditAnywhere)
	UPaperFlipbook* MoveFlipbook;
	UPROPERTY(EditAnywhere)
	UPaperFlipbook* DodgeFlipbook;
	UPROPERTY(EditDefaultsOnly,BlueprintReadWrite,Category="PlayerBoxComponent")
	UBoxComponent* PlayerBoxComponent;
	UPROPERTY(VisibleAnywhere,BlueprintReadWrite,Category="Weapon")
	UPaperSpriteComponent* Weapon;
	UPROPERTY()
	UPaperSprite* LongRangeWeapon;
	UPROPERTY(VisibleAnywhere,Category="MYSprite")
	UPaperFlipbookComponent* MYSprite;
	UPROPERTY()
	UPaperSprite* MeleWeapon;
	virtual void BeginPlay() override;
	virtual void Tick(float DeltaSeconds) override;
	
protected:
	UPROPERTY(VisibleAnywhere,Category="SpringArm")
	USpringArmComponent* SpringArm;
	UPROPERTY(VisibleAnywhere,BlueprintReadWrite,Category="Camera")
	UCameraComponent* Gampplayer;
	//UPROPERTY()
	//Umove
	UFUNCTION()
	void PlayerInitializetion();
	UFUNCTION()
//	void OnBoxEndOverlap(  UPrimitiveComponent* OverlappedComponent,AActor* OtherActor,UPrimitiveComponent* OtherComp,int32 OtherBodyIndex);
	virtual void SetupPlayerInputComponent(UInputComponent* PlayerInputComponent) override;
	void MoveY(float Value);
	void MoveX(float Value);
	
	
	void ThrowBoomerang();
	void UpdateBoomerang(float DeltaSeconds);
	void UpdateCharacterAnimation();
	bool IsMoving() const;

private:
	AA_PlayerCharacter();
	void SwitchToNextWeapon();
	void UpdateFacingDirection();
	
};
