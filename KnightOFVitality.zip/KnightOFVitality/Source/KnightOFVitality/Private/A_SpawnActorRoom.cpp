// Fill out your copyright notice in the Description page of Project Settings.


#include "A_SpawnActorRoom.h"


// Sets default values
AA_SpawnActorRoom::AA_SpawnActorRoom()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;
	RootScene = CreateDefaultSubobject<USceneComponent>(TEXT("场景根组件"));
	RootScene = RootComponent;
	CorridorMesh = CreateDefaultSubobject<UInstancedStaticMeshComponent>(TEXT("CorridorMesh"));
	RoomClass = AA_Room::StaticClass();
	static ConstructorHelpers::FObjectFinder<UStaticMesh> MeshAsset(TEXT("/Script/Engine.StaticMesh'/Game/1.1'"));
	if (MeshAsset.Succeeded())
	{
		CorridorMesh->SetStaticMesh(MeshAsset.Object);
	}
}
void AA_SpawnActorRoom::GenerateRooms(int RoomCount)
{
	ClearAllRooms();


	LastRoomLocation = FVector::ZeroVector;
	SpawnRoom(LastRoomLocation,FVector2D(1,1),0);
	CurrentDirction.Add(LastRoomLocation);
	for (int i = 1; i < RoomCount; i++)
	{
		FVector FVEND;
		FVector Offset;
		int MaxAttempts = 10; // 避免死循环
		int Attempt = 0;
		bool bValidLocation = false;

		do
		{
			const int Dir = FMath::RandRange(0, 3);
			Offset = GetDirectionOffset(Dir) * 500.0f;
			FVEND = LastRoomLocation + Offset;

			// 如果是最后一个房间，并且位置等于上一个，也可以接受
			if (i == RoomCount - 1 && FVEND == LastRoomLocation)
			{
				bValidLocation = true;
				break;
			}

			// 如果这个位置还没有被使用
			if (!CurrentDirction.Contains(FVEND))
			{
				bValidLocation = true;
				break;
			}

			Attempt++;
		}
		while (!bValidLocation && Attempt < MaxAttempts);

		if (bValidLocation)
		{
			// 生成走廊和房间
			SpawnCorridor(LastRoomLocation, FVEND);
			LastRoomLocation = FVEND;

			FVector2D RandomScale = FVector2D(FMath::RandRange(1.0f, 3.0f), FMath::RandRange(1.0f, 3.0f));
			int RoomTag = (i == 0) ? int(0) : (i == RoomCount - 1) ? int(2) : int(1);
			UE_LOG(LogTemp, Warning, TEXT("RoomTag: %d"), RoomTag);
			SpawnRoom(LastRoomLocation, RandomScale, RoomTag);
			CurrentDirction.Add(FVEND);
		}
	}
	
		


		
}	
// Called when the game starts or when spawned
void AA_SpawnActorRoom::BeginPlay()
{
	Super::BeginPlay();
	GenerateRooms(FMath::RandRange(3,NumberLevels));
}

void AA_SpawnActorRoom::SpawnRoom(FVector Location, FVector2D Scale, int RoomType)
{
	FVector ScaleZ = FVector(Scale.X,1.0f,Scale.Y);
	if (RoomClass)
	{
		AA_Room* Room = GetWorld()->SpawnActor<AA_Room>(RoomClass, Location,FRotator::ZeroRotator);
		if (Room)
		{
		
			Room->SetActorScale3D(ScaleZ);
			Room->SetFNameFu(RoomType);
			Room->LoadAssets();
			SpawnedRooms.Add(Room);
		}
	}
}

void AA_SpawnActorRoom::SpawnCorridor(FVector Start, FVector End)
{
	if (!CorridorMesh) return;
	//这个是固定的mesh，如果换成其他网格体需要重新适配数值
	// mesh计算方向和长度
	FVector Direction = End - Start;
	float Length = Direction.Size();

	// 中点：用于 Mesh 放置位置
	FVector MidPoint = (Start + End) * 0.5f;
	

	// 旋转：使 Mesh 朝向目标方向
	FRotator Rotation = Direction.Rotation();

	// 缩放（拉长 X 轴）
	float MeshBaseLength = 100.0f; // Cube 原始大小
	float ScaleX = Length / MeshBaseLength;

	FVector Scale = FVector(ScaleX, 1.0f, 1.0f);

	// 让 Mesh 的底部贴地 or 贴 Sprite 平面（如果你的 Sprite Z 是 0）
	// 保持比房间 Sprite低
	MidPoint.Z = MeshBaseLength * 0 -(MeshBaseLength/2 + 5); 
	CorridorMesh->SetRelativeLocation(FVector(0,0,0));
	// 构建实例 Transform
	FTransform InstanceTransform;
	InstanceTransform.SetLocation(MidPoint);
	InstanceTransform.SetRotation(Rotation.Quaternion());
	InstanceTransform.SetScale3D(Scale);

	// 添加实例
	CorridorMesh->AddInstance(InstanceTransform);
}

FVector AA_SpawnActorRoom::GetDirectionOffset(int Direction)
{
	switch (Direction)
	{
	case 0: return FVector(1, 0, 0); // +X
	case 1: return FVector(-1, 0, 0); // -X
	case 2: return FVector(0, 1, 0); // +Y
	case 3: return FVector(0, -1, 0); // -Y
	default: return FVector::ZeroVector;
	}
}

void AA_SpawnActorRoom::ClearAllRooms()
{
	for (AActor* Room : SpawnedRooms)
	{
		if (Room) Room->Destroy();
	}
	SpawnedRooms.Empty();
}