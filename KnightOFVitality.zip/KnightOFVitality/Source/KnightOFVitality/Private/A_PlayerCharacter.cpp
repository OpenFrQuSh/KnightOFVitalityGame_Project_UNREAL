// Fill out your copyright notice in the Description page of Project Settings.


#include "A_PlayerCharacter.h"

#include "Kismet/KismetSystemLibrary.h"


AA_PlayerCharacter::AA_PlayerCharacter()
{
	PrimaryActorTick.bCanEverTick = true;
	PlayerBoxComponent = CreateDefaultSubobject<UBoxComponent>(TEXT("BoxRoomComponent"));
	PlayerBoxComponent->SetBoxExtent(FVector(5,6,50));
	PlayerBoxComponent->SetCollisionProfileName(TEXT("Pawn"));
	PlayerBoxComponent->SetCollisionResponseToChannel(ECC_WorldDynamic,ECR_Overlap);
	PlayerBoxComponent->SetCollisionResponseToChannel(ECC_PhysicsBody,ECR_Overlap);
	//PlayerBoxComponent->OnComponentEndOverlap.AddDynamic(this, &AA_PlayerCharacter::OnBoxEndOverlap);
	RootComponent = PlayerBoxComponent;

	bUseControllerRotationYaw = false;
	MYSprite = CreateDefaultSubobject<UPaperFlipbookComponent>(TEXT("PaperFlipbookComponent"));
	Boxdamage = CreateDefaultSubobject<UBoxComponent>(TEXT("Boxdamage"));
	Weapon = CreateDefaultSubobject<UPaperSpriteComponent>("SpriteComponent");
	SpringArm = CreateDefaultSubobject<USpringArmComponent>("SpringArm");
	Gampplayer = CreateDefaultSubobject<UCameraComponent>("Camera");
	SpringArm->SetupAttachment(PlayerBoxComponent);
	Gampplayer->SetupAttachment(SpringArm);
	SpringArm->bDoCollisionTest = false;
	MYSprite->SetupAttachment(PlayerBoxComponent);
	Boxdamage->SetupAttachment(Weapon);
	MYSprite->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	MYSprite->SetGenerateOverlapEvents(false);
	Weapon->SetCollisionEnabled(ECollisionEnabled::QueryOnly);
	Weapon->SetCollisionObjectType(ECC_WorldDynamic);
	Weapon->SetCollisionResponseToAllChannels(ECR_Overlap);
	Weapon->SetCollisionResponseToChannel(ECC_Pawn, ECR_Ignore);
	Weapon->SetCollisionResponseToChannel(ECC_PhysicsBody, ECR_Ignore);
	Boxdamage->SetCollisionResponseToChannel(ECC_PhysicsBody, ECR_Ignore);
	SpringArm->bDoCollisionTest = false;
	
	
	

	
	SpringArm->SetRelativeRotation(FRotator(-90,0,0));
	LongRangeWeapon = LoadObject<UPaperSprite>(nullptr, TEXT("/Script/Paper2D.PaperSprite'/Game/Assets/wuqi2_Sprite.wuqi2_Sprite'"));
	IdleFlipbook = LoadObject<UPaperFlipbook>(nullptr,TEXT("/Script/Paper2D.PaperFlipbook'/Game/Assets/CharacterSequence/Sprite_IDEL.Sprite_IDEL'"));
	MoveFlipbook = LoadObject<UPaperFlipbook>(nullptr,TEXT("/Script/Paper2D.PaperFlipbook'/Game/Assets/CharacterSequence/Sprite_Move.Sprite_Move'"));
	DodgeFlipbook = LoadObject<UPaperFlipbook>(nullptr,TEXT("/Script/Paper2D.PaperFlipbook'/Game/Assets/CharacterSequence/Sprite_fangui.Sprite_fangui'"));
	MeleWeapon = LoadObject<UPaperSprite>(nullptr, TEXT("/Script/Paper2D.PaperFlipbook'/Game/Assets/CharacterSequence/Sprite_fangui.Sprite_fangui'"));
	MoveSpeed = 50.0f;
	bIsThrowingBoomerang = false;
	bIsRolling = false;
	bIsAttacking = false;
	BoomerangSpeed = 100;
	MaxBoomerangDistance = 100.0f;
	BoomerangElapsed = 0.0f;

	if (MYSprite)
	{
		Weapon->SetupAttachment(MYSprite);
		PlayerInitializetion();

	}
}

void AA_PlayerCharacter::BeginPlay()
{
	Super::BeginPlay();
	PC = Cast<APlayerController>(GetWorld()->GetFirstPlayerController());
	PC->bShowMouseCursor = true;
	PlayerInitializetion();
	if (PC)
	{
		
		EnableInput(PC);
	}
}
void AA_PlayerCharacter::Tick(float DeltaSeconds)
{
	Super::Tick(DeltaSeconds);
	
	UpdateCharacterAnimation();
	UpdateFacingDirection();
	if (bIsThrowingBoomerang)
	{
		UpdateBoomerang(DeltaSeconds);
	}
#if WITH_EDITOR
	if (GEngine)
	{
		FString InputText = FString::Printf(TEXT("InputX: %.2f | InputY: %.2f"), CurrentInputX, CurrentInputY);
		GEngine->AddOnScreenDebugMessage(-1, 0.f, FColor::Green, InputText);
	}
#endif
	FVector Start = GetActorLocation();
	FVector End = Start - FVector(0, 0, 0); 

	FVector BoxExtent = FVector(10, 10, 50); // 检测区域大小

	FCollisionShape Box = FCollisionShape::MakeBox(BoxExtent);

	FHitResult HitResult;

	FCollisionQueryParams Params;
	Params.AddIgnoredActor(this); // 忽略自身

	bool bHit = GetWorld()->SweepSingleByChannel(
		HitResult,
		Start,
		End,
		FQuat::Identity,
		ECC_WorldDynamic,  // 只检测 WorldDynamic
		Box,
		Params
	);

	if (!bHit)
	{
		// 没有检测到任何 WorldDynamic 物体，销毁
		UKismetSystemLibrary::QuitGame(this, PC, EQuitPreference::Quit, true);
		
	}

	// Optional: 可打印调试框
	DrawDebugBox(GetWorld(), End, BoxExtent, FColor::Red, false, 0.1f);
}

//角色生成后初始化设置，调整正确方向
void AA_PlayerCharacter::PlayerInitializetion()
{
	//判断sprite组件和图像序列帧是否有效
	//有效则执行赋值，设置旋转，播放序列帧动画。
	SpringArm->TargetArmLength = 150;
	SpringArm->bEnableCameraLag = true;
	SpringArm->CameraLagSpeed = 2;
	
		if (IdleFlipbook && MYSprite)
		{
			Gampplayer->SetRelativeRotation(FRotator(0,0,-90));
			MYSprite->SetRelativeRotation(FRotator(0,0,-90));
			MYSprite->SetRelativeScale3D(FVector(0.5,0.5,0.5));
			MYSprite->SetFlipbook(IdleFlipbook);
			MYSprite->SetPlayRate(1.0f);
			MYSprite->SetPlaybackPositionInFrames(0,true);
			MYSprite->SetLooping(true);
			MYSprite->Play();
			MYSprite->MarkRenderStateDirty();
			MYSprite->RecreateRenderState_Concurrent();
			UE_LOG(LogTemp, Warning, TEXT("成功调用play，播放开始"));
			Weapon->SetSprite(LongRangeWeapon);
			Weapon->SetRelativeTransform(FTransform(FRotator(0,0,0),FVector(1,2,-5.0),FVector(0.5f,0.5f,0.5f)));
		}
		
		
}

void AA_PlayerCharacter::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
	Super::SetupPlayerInputComponent(PlayerInputComponent);
	UE_LOG(LogTemp, Warning, TEXT("SetupPlayerInputComponent绑定输入成功"));
	PlayerInputComponent->BindAxis("Character_PlayerMoveX", this, &AA_PlayerCharacter::MoveX);
	PlayerInputComponent->BindAxis("Character_PlayerMoveY", this, &AA_PlayerCharacter::MoveY);
	PlayerInputComponent->BindAction("ThrowBoomerang", IE_Pressed, this, &AA_PlayerCharacter::ThrowBoomerang);
	
}

void AA_PlayerCharacter::MoveX(float Value)
{
	CurrentInputX = Value;

	if (bIsRolling || FMath::IsNearlyZero(Value)) return;

	if (FMath::Abs(Value) > KINDA_SMALL_NUMBER)
	{
		AddActorWorldOffset(FVector(0, Value * MoveSpeed * GetWorld()->GetDeltaSeconds(), 0), true);
		//PlayMoveAnimation();
	}
}

void AA_PlayerCharacter::MoveY(float Value)
{
	CurrentInputY = Value;

	if (bIsRolling || FMath::IsNearlyZero(Value)) return;

	if (FMath::Abs(Value) > KINDA_SMALL_NUMBER)
	{
		AddActorWorldOffset(FVector(Value * MoveSpeed * GetWorld()->GetDeltaSeconds(), 0, 0), true);
		//PlayMoveAnimation();
	}
}
/*void AA_PlayerCharacter::EndDodge()
{
	bIsRolling = false;
	if (IdleFlipbook) MYSprite->SetFlipbook(IdleFlipbook);
}
*/



void AA_PlayerCharacter::SwitchToNextWeapon()
{
	// 示例：循环武器数组，或切换Sprite、Socket挂点等
	// WeaponIndex = (WeaponIndex + 1) % WeaponList.Num();
	// AttachWeapon(WeaponList[WeaponIndex]);
}

//角色朝向
void AA_PlayerCharacter::UpdateFacingDirection()
{
	if (PC)
	{
		float MouseX, MouseY;
		PC->GetMousePosition(MouseX, MouseY);

		FVector2D ScreenPos;
		PC->ProjectWorldLocationToScreen(GetActorLocation(), ScreenPos);

		// 鼠标在角色右边
		bool bFacingRight = MouseX > ScreenPos.X;
		MYSprite->SetRelativeScale3D(FVector(bFacingRight ? 0.5 : - 0.5, bFacingRight ?  0.5 : - 0.5,  0.5));
		Weapon->SetRelativeLocation(FVector(bFacingRight ? 1 : -1,bFacingRight ? 2 : -2,-5));
	}
}
void AA_PlayerCharacter::ThrowBoomerang()
{
	if (bIsThrowingBoomerang || !PC) return;

	// 使用射线检测鼠标指向的世界位置
	FHitResult HitResult;
	if (PC->GetHitResultUnderCursor(ECC_Visibility, false, HitResult))
	{
		FVector StartLocation = GetActorLocation();
		FVector TargetLocation = HitResult.ImpactPoint;

		// 只取XY平面方向
		FVector2D Start2D(StartLocation.X, StartLocation.Y);
		FVector2D Target2D(TargetLocation.X, TargetLocation.Y);
		FVector2D Direction2D = (Target2D - Start2D).GetSafeNormal();

		// 初始化
		BoomerangStartLocation = Start2D;
		BoomerangDirection = Direction2D;
		BoomerangElapsed = 0.0f;
		bIsThrowingBoomerang = true;

		
	}
	
}
void AA_PlayerCharacter::UpdateBoomerang(float DeltaSeconds)
{
	if (!bIsThrowingBoomerang) return;

	BoomerangElapsed += DeltaSeconds * BoomerangSpeed;

	float t = FMath::Clamp(BoomerangElapsed / MaxBoomerangDistance, 0.0f, 1.0f);
	float ArcFactor = (t < 0.5f) ? t * 2 : (1.0f - t) * 2;

	FVector BoomerangWorldLocation = FVector(
		BoomerangStartLocation + BoomerangDirection * MaxBoomerangDistance * ArcFactor,
		GetActorLocation().Z // 保持Z不变
	);

	Weapon->SetWorldLocation(BoomerangWorldLocation);

	if (t >= 1.0f)
	{
		bIsThrowingBoomerang = false;
	}
}
void AA_PlayerCharacter::UpdateCharacterAnimation()
{
	if (bIsRolling)
	{
		MYSprite->SetFlipbook(DodgeFlipbook);
	}
	else if (IsMoving())
	{
		MYSprite->SetFlipbook(MoveFlipbook);
	}
	else
	{
		MYSprite->SetFlipbook(IdleFlipbook);
	}
}
bool AA_PlayerCharacter::IsMoving() const
{
	return !FMath::IsNearlyZero(CurrentInputX) || !FMath::IsNearlyZero(CurrentInputY);
}

