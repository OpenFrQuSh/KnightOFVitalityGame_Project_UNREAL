// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "A_Room.h"
#include "Components/InstancedStaticMeshComponent.h"
#include "A_PlayerCharacter.h"
//必要头文件
#include "GameFramework/Actor.h"
#include "A_SpawnActorRoom.generated.h"

UCLASS()
class AA_SpawnActorRoom : public AActor
{
	GENERATED_BODY()
	
public:	
	// Sets default values for this actor's properties
	AA_SpawnActorRoom();
	UFUNCTION(BlueprintCallable)
	void GenerateRooms(int RoomCounter);
	//声明一个类型
	TSubclassOf<AA_Room> RoomClass;
	UPROPERTY(VisibleAnywhere,Category = "Scene")
	USceneComponent* RootScene;
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite,Category = "Corridor")
	//使用InstanceMesh,减少性能开销，并且走廊也符合统一渲染
	UInstancedStaticMeshComponent* CorridorMesh;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "NumberLevels")
	int NumberLevels  = 5;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "RoomCounter")
	int RoomCounter;
	
protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;
private:
	FVector LastRoomLocation;
	UPROPERTY()
	TArray<AActor*> SpawnedRooms;
	
	

	void ClearAllRooms();
	void SpawnRoom(FVector Location, FVector2D Scale,  int RoomType);
	void SpawnCorridor(FVector Start, FVector End);
	FVector GetDirectionOffset(int Direction);
	TArray<FVector> CurrentDirction;
};
