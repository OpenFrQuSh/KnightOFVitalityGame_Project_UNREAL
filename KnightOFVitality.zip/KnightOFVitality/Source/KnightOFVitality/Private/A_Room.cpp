// Fill out your copyright notice in the Description page of Project Settings.


#include "A_Room.h"

// Sets default values
AA_Room::AA_Room()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;
	//初始化设置和初始化赋值
	RootComponent = CreateDefaultSubobject<USceneComponent>(TEXT("RootScene"));

	UFloorSprite = CreateDefaultSubobject<UPaperSpriteComponent>(TEXT("FloorSpriteComponent"));
	UFloorSprite->SetupAttachment(RootComponent);
	BOXROOM = CreateDefaultSubobject<UBoxComponent>(TEXT("boxroom"));
	BOXROOM->SetupAttachment(RootComponent);
	BOXROOM->SetHiddenInGame(true);
	BOXROOM->SetBoxExtent(FVector(50,60,32));
	BOXROOM->SetCollisionObjectType(ECC_PhysicsBody);
	BOXROOM->SetCollisionResponseToAllChannels(ECR_Ignore);
	BOXROOM->SetCollisionResponseToChannel(ECC_Pawn, ECR_Overlap); 
	BOXROOM->OnComponentBeginOverlap.AddDynamic(this, &AA_Room::OnBoxBeginOverlap);
	static ConstructorHelpers::FObjectFinder<UPaperSprite> SpriteRef(TEXT("/Game/Assets/diban_Sprite.diban_Sprite"));
	SpriteAsset = SpriteRef.Object;
	
	MinSpawnBlueprint = 1;
	MaxSpawnBlueprint = 8;
	
	

	RoomTagarray =
	{
		"PointOfBirth_A",
		"MonsterRoom_B",
		"RoomTeleportation_C",
	};
	
}

// Called when the game starts or when spawned
void AA_Room::BeginPlay()
{
	Super::BeginPlay();

	//运行时设置位置防止在同一图层
	UFloorSprite->SetRelativeLocation(FVector(0.0f, 0.0f, -1.0f));
	if (GEngine)
	{
		FString Msg = FString::Printf(TEXT("CurrentRoomName: %s"), *CurrentRoomNmae.ToString());
		GEngine->AddOnScreenDebugMessage(
			-1,                  // 多刷
			5.0f,               // 持续时间（秒）
			FColor::Green,      // 字体颜色
			Msg                 // 要显示的内容
		);
		
	}
	UE_LOG(LogTemp, Warning, TEXT("CurrentRoomName: %s"), *CurrentRoomNmae.ToString());
	}

// Called every frame
void AA_Room::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}

void AA_Room::LoadAssets()
{
	
	if (SpriteAsset && UFloorSprite)
	{
		UFloorSprite->SetSprite(SpriteAsset);
		
		UFloorSprite->SetRelativeRotation(FRotator(0.0f,0.0f,90.0f));
		
	}
}

void AA_Room::SetFNameFu(int Quantiy)
{
	if (RoomTagarray.IsValidIndex(Quantiy))
	{
		CurrentRoomNmae = RoomTagarray[Quantiy];
	}
	 
}

void AA_Room::OnBoxBeginOverlap(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor,UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep,const FHitResult& SweepResult)
{
	if (OtherActor && OtherActor != this)
	{
		BOXROOM->DestroyComponent();
		
		
		if (CurrentRoomNmae == "MonsterRoom_B")
		{
			// 使用 CalcBounds 获取世界范围包围盒
			FBoxSphereBounds Bounds = UFloorSprite->CalcBounds(UFloorSprite->GetComponentTransform());

			FVector Origin = Bounds.Origin;         // Sprite 中心
			FVector Extent = Bounds.BoxExtent;      // Sprite 半长宽高（已考虑缩放）

			// 可视化整个生成范围
			DrawDebugBox(GetWorld(), Origin, Extent, FColor::Green, false, 10.0f, 0, 2.0f);

			// 随机生成数量
			int32 SpawnCount = FMath::RandRange(MinSpawnBlueprint, MaxSpawnBlueprint);

			for (int32 i = 0; i < SpawnCount; ++i)
			{
				// 随机生成坐标（XY 平面）
				FVector RandomOffset = FVector(
					FMath::FRandRange(-Extent.X, Extent.X),
					FMath::FRandRange(-Extent.Y, Extent.Y),
					1.0f
				);

				FVector SpawnLocation = Origin + RandomOffset;

				// 可视化每个小怪位置
				DrawDebugSphere(GetWorld(), SpawnLocation, 16.0f, 12, FColor::Red, false, 10.0f);
				FActorSpawnParameters SpawnParams;
				SpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
				// 加载小怪 Blueprint，随机加载近战和远程
				TArray<FString> MonsterPaths = {
					TEXT("/Game/Enemy/BP_Enemy_1.BP_Enemy_1_C"),
					TEXT("/Game/Enemy/BP_Enemy_2.BP_Enemy_2_C")
				};

				FString RandomPath = MonsterPaths[FMath::RandRange(0, MonsterPaths.Num() - 1)];
				UClass* MonsterClass = StaticLoadClass(AActor::StaticClass(), nullptr, *RandomPath);

				if (MonsterClass)
				{
					GetWorld()->SpawnActor<AActor>(MonsterClass, SpawnLocation, FRotator::ZeroRotator,SpawnParams);
				}
			}
		}
		else if (CurrentRoomNmae == "RoomTeleportation_C")
		{
			UE_LOG(LogTemp, Warning, TEXT("检测到 RoomTeleportation_C，准备生成传送装置"));

			FVector SpawnLocation = GetActorLocation() + FVector(0, 0, 50);
			FRotator SpawnRotation = FRotator::ZeroRotator;

			UClass* TeleportBPClass = StaticLoadClass(AActor::StaticClass(), nullptr, TEXT("/Game/Blueprints/BP_AttributeMET.BP_AttributeMET_C"));
			if (TeleportBPClass)
			{
				GetWorld()->SpawnActor<AActor>(TeleportBPClass, SpawnLocation, SpawnRotation);
			}
			else
			{
				UE_LOG(LogTemp, Error, TEXT("加载 BP_AttributeMET 蓝图失败"));
			}
		}
	}
	
}

