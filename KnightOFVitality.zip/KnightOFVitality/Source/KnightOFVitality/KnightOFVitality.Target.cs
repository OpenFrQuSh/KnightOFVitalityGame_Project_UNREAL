﻿// KnightOFVitality.Target.cs

using UnrealBuildTool;
using System.Collections.Generic;

public class KnightOFVitalityTarget : TargetRules
{
	public KnightOFVitalityTarget(TargetInfo Target) : base(Target)
	{
		Type = TargetType.Game;
		DefaultBuildSettings = BuildSettingsVersion.V5;
		ExtraModuleNames.Add("KnightOFVitality");
	}
}